DB records




 # Insert user records
    users = [('john123', 'password1'),
             ('mary456', 'password2'),
             ('peter789', 'password3'),
             ('susan012', 'password4'),
             ('bob345', 'password5')]


    # Insert medical report records
    reports = [('john123', '2023-01-01', 'Symptoms: Headache. Medication: Paracetamol. Tests: Blood test.'),
               ('john123', '2023-01-02', 'Symptoms: Cough. Medication: Cough Syrup. Tests: Throat swab.'),
               ('mary456', '2023-02-01', 'Symptoms: Fever. Medication: Ibuprofen. Tests: Blood test.'),
               ('mary456', '2023-02-02', 'Symptoms: Runny nose. Medication: Antihistamine. Tests: Allergy test.'),
               ('peter789', '2023-03-01', 'Symptoms: Stomach ache. Medication: Antacid. Tests: Ultrasound.'),
               ('peter789', '2023-03-02', 'Symptoms: Nausea. Medication: Pepto-Bismol. Tests: Blood test.'),
               ('susan012', '2023-04-01', 'Symptoms: Joint pain. Medication: Ibuprofen. Tests: X-ray.'),
               ('susan012', '2023-04-02', 'Symptoms: Back pain. Medication: Paracetamol. Tests: MRI.'),
               ('bob345', '2023-05-01', 'Symptoms: Chest pain. Medication: Aspirin. Tests: EKG.'),
               ('bob345', '2023-05-02', 'Symptoms: Shortness of breath. Medication: Albuterol. Tests: Spirometry.')]